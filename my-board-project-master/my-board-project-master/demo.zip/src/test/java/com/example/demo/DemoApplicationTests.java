package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import com.example.demo.repository.BoardMapper;



public class DemoApplicationTests {


	BoardMapper boardMapper;

	Map<String, Object> sample = new HashMap<>();

	

}
