package com.example.demo.service;

public class Sample1Impl implements SampleInterface {

	@Override
	public void sample() {
		// TODO Auto-generated method stub

	}

}
